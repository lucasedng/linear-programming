RationalSimplex.jl
==================

[![Build Status](https://travis-ci.org/IainNZ/RationalSimplex.jl.svg?branch=master)](https://travis-ci.org/IainNZ/RationalSimplex.jl)

[Julia](https://julialang.org/) implementation of the
[Simplex algorithm](https://en.wikipedia.org/wiki/Simplex_algorithm)
for [rational numbers](https://en.wikipedia.org/wiki/Rational_number).
Intended for educational and experimental purposes only.
See code for documentation, or tests for examples.

Last updated on 2018/07/01, tested with Julia 0.7-beta.